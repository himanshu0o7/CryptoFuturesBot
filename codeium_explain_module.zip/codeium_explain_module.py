import os
import openai
import argparse

# Load OpenAI API key
openai.api_key = os.getenv("OPENAI_API_KEY")

def explain_code_block(code_block):
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are an expert Python developer. Explain or fix code."},
                {"role": "user", "content": f"Explain or fix the following code:
{code_block}"}
            ]
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        return f"Error: {e}"

def extract_target_blocks(file_path):
    with open(file_path, 'r') as f:
        lines = f.readlines()

    blocks = []
    block = []
    inside_block = False
    for line in lines:
        if line.strip().startswith('# EXPLAIN:') or line.strip().startswith('# FIX:'):
            if block:
                blocks.append(''.join(block))
                block = []
            inside_block = True
            block.append(line)
        elif inside_block:
            if line.strip() == '':
                blocks.append(''.join(block))
                block = []
                inside_block = False
            else:
                block.append(line)

    if block:
        blocks.append(''.join(block))
    return blocks

def process_file(file_path):
    blocks = extract_target_blocks(file_path)
    for i, block in enumerate(blocks):
        print(f"\n🔍 Block {i+1}:")
        print(block)
        suggestion = explain_code_block(block)
        print("✅ Suggestion:")
        print(suggestion)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Explain/Fix Python code blocks marked with # EXPLAIN: or # FIX:")
    parser.add_argument('file', help='Path to the Python file')
    args = parser.parse_args()
    process_file(args.file)
