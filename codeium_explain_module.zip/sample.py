# EXPLAIN:
def greet(name):
    print(f"Hello, {name}!")

# FIX:
def divide(a, b):
    return a / b
